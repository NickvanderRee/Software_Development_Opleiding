<?php
// functie: Programma CRUD Films
// auteur: Nick van der Ree 

// Initialisatie
include 'functions.php';

// Main

// Print Films opdracht 12
CrudFilms();


?>