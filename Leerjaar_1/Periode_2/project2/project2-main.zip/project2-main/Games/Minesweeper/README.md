WERKING VAN HET SPEL:
==================================================
Minesweeper is een logisch spel waarbij de speler een raster van vakjes moet onthullen zonder op een mijn te stappen. Het spel begint met een groot aantal vakjes bedekt. De speler kan een vakje onthullen door erop te klikken. Als er een mijn onder een vakje ligt, verliest de speler het spel. Als er geen mijn onder een vakje ligt, wordt het aantal mijnen weergegeven dat zich in de directe omgeving van het vakje bevindt. Dit wordt aangegeven met cijfers die in het vakje worden weergegeven.
==================================================

VLAGGEN PLAATSEN:
==================================================
De speler kan ook een vlag plaatsen op een vakje waarvan hij vermoedt dat er een mijn onder ligt, door met de linkermuisknop op het vlaggen vakje te klikken. Als de speler een vakje onthult waar een vlag staat, wordt er geen verlies genoteerd. Als er een mijn onder een vakje ligt waar geen vlag staat, verliest de speler het spel.
==================================================

HET DOEL:
==================================================
Het doel van het spel is om alle vakjes te onthullen zonder op een mijn te stappen. De speler kan dit doen door gebruik te maken van logica en redenering, door te bepalen welke vakjes veilig zijn om te onthullen op basis van de cijfers die worden weergegeven.
==================================================